self.__NEXT_FONT_MANIFEST={
  "pages": {
    "/_app": []
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": false
}